//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SampleViewer.rc
//
#define IDD_VIEWER_TINT                 134
#define IDC_VIEWER_TINT_DEC             1001
#define IDC_VIEWER_TINT_HEXA            1002
#define IDC_VIEWER_TINT_BIN             1003
#define IDC_VIEWER_TINT_ASCII           1004
#define IDC_VIEWER_TINT_DUMP            1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
